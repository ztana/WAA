/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mum.waa.webstore.controller;

import edu.mum.waa.webstore.service.ProductRepository;
import edu.mum.waa.webstore.ProductRepository.impl.InMemoryProductRepository;
import edu.mum.waa.webstore.domain.Product;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author 984881
 */
@Controller
public class ProductController {
    
    @Autowired
    private ProductRepository productRepoistory;
    
    @RequestMapping("/products")
    public String getAllProducts(Model model) {
       
        model.addAttribute("products",productRepoistory.getAllProducts());
        return "products";
    }

    
    
}
