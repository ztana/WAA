/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mum.waa.webstore.ProductRepository.impl;

import edu.mum.waa.webstore.service.ProductRepository;
import edu.mum.waa.webstore.domain.Product;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

/**
 *
 * @author 984881
 */
@Repository
public class InMemoryProductRepository implements ProductRepository {
    
    private List<Product> listOfProducts;

    public InMemoryProductRepository() {
        
        if(listOfProducts == null)
            listOfProducts = new ArrayList();
        
        Product iphone = new Product("P12","iPhone",BigDecimal.valueOf(500));
        iphone.setDescription("iphone 5s");
        iphone.setCategory("phone");
        iphone.setCondition("new");
        iphone.setManufacturer("apple");
        iphone.setUnitsInStock(100);
        
        Product samsung = new Product("P11","Samsumg",BigDecimal.valueOf(400));
        samsung.setDescription("SS s5");
        samsung.setCategory("phone");
        samsung.setCondition("new");
        samsung.setManufacturer("samsung");
        samsung.setUnitsInStock(80);
        
        listOfProducts.add(iphone);
        listOfProducts.add(samsung);
    }

    /**
     * override interface
     * @return
     */
    @Override
    public List<Product> getAllProducts() {
        return listOfProducts;
    }

    @Override
    public Product getProductById(String productId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
